# G. Manohar — redesigned portfolio

A complete static website. Open `index.html` to review locally, or serve this folder with a static web server. Internet access is needed only for Google Fonts and external links; the layout has system-font fallbacks.

## Files

- `index.html`: homepage and client-facing service copy.
- `assets/style.css`: responsive visual design.
- `assets/site.js`: accessible mobile navigation.
- `projects/`: project index and all nine existing project routes.
- `experience/`: career, education and recognition.
- `uploads/resume.pdf`: original CV, unchanged.

## Publish to the existing GitHub Pages address

This is a static replacement for the existing Hugo implementation, not a Hugo theme patch. Preserve the existing repository history and make the change on a review branch.

1. Copy this package into a new `redesign/` folder in the Portfolio repository.
2. Replace the contents of the existing `.github/workflows/deploy.yml` with the workflow below. Do not leave the old Hugo deployment enabled alongside it.
3. Review the branch changes and merge when ready. In repository Settings → Pages, the deployment source should be GitHub Actions.
4. After the deployment succeeds, verify the homepage, project pages and CV at `https://manohargov.github.io/Portfolio/`.

```yaml
name: Deploy portfolio
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: pages
  cancel-in-progress: false
jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/configure-pages@v5
      - uses: actions/upload-pages-artifact@v3
        with:
          path: redesign
      - name: Deploy
        id: deployment
        uses: actions/deploy-pages@v4
```

Relative links support the existing `/Portfolio/` base path. The project detail and CV paths are retained; old tag, author and feed routes are not recreated in this static package. The Hugo source can stay in the repository for reference and rollback but is not used by this workflow.

The supplied CV still describes the historical 10-person ML team. The profile separately uses the user-supplied 120 software engineer leadership figure. Update the CV later with role/time-period context if needed.

There is no form backend, tracking or scheduling integration. Contact links open an email application or the existing professional profiles. No remote repository or live deployment was modified when preparing this package.

## Local link correction

All internal page links now name `index.html` explicitly, so the complete extracted folder can be opened directly from disk as well as served on GitHub Pages. Extract the entire ZIP before opening the homepage; do not move the HTML file away from its assets and project folders.
